<script src="<?=base_url()?>assets/js/highcharts.js"></script>
<script src="<?=base_url()?>assets/js/funnel.js"></script>
<script src="<?=base_url()?>assets/js/exporting.js"></script>
<script>

$(function () {
    $('#sales_pipeline').highcharts({
		
		
        chart: {
            type: 'funnel',
            marginRight: 100
        },
        title: {
            text: '',
            x: -50
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} ({point.y:,.0f})',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                },
                neckWidth: '30%',
                neckHeight: '25%'
                
                //-- Other available options
                // height: pixels or percent
                // width: pixels or percent
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: 'Deals',
			dataType: "json",
            data: [ <?php if ($pipelinechart[0]) { 
	for($h=0;count($pipelinechart)>$h;$h++)
	{
		echo "['".$pipelinechart[$h]['Department']."',".$pipelinechart[$h]['Budget']."],";
	 } ?><?php } else { ?>
 				['Negotiation',15654],
                ['Purchasing',4064],
                ['Won',1987],
                ['Lost',976],
                ['Archieved',846]
              <?php } ?> 
            ]
        }]
    });
	
	
	
	$('.highcharts-series-group path').hover(
    function(){
		var div=$(this).attr('id');
		var fill=$(this).attr('fill');
		$('#color').val(fill);
		//$('#'+div).css('fill', '#00C8C8');
		$('#'+div).css('stroke-width', '10px'); }, // over
    function(){
		var div=$(this).attr('id');
		var fill=$(this).attr('fill');
		 $('#'+div).css('fill', fill);
		$('#'+div).css('stroke-width', '1px');
		}  // out
);
$('.highcharts-series-group path').click(function(){
	var div=$(this).attr('id');
	window.location.replace(appBaseUrl+'deals');

});
});
</script>
<script>

$(document).ready(function () {    

           // Radialize the colors
	
            RenderPieChart('cases_priority1', [["High",1],["Medium",2],["low",1]]);     
     
     
     
            function RenderPieChart(elementId, dataList) {
				
                new Highcharts.Chart({
                    chart: {
                        renderTo: elementId,
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false
                    }, title: {
                        text: ''
                    },
                    tooltip: {
                        formatter: function () {
							
							
                            return '<b>' + this.point.name + '</b>: ' + this.point.y;
                        }
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                color: '#000000',
                                connectorColor: '#000000',
                                formatter: function () {
									
                                    return this.point.name + ': ' + this.point.y ;
                                }
                            }
                        }
                    },
                    series: [{
                        type: 'pie',
                        name: '',
                        data: dataList
                    }]
                });
            };
			
			
        });




</script>

<script src="http://code.highcharts.com/highcharts.js"></script>
<script src="http://code.highcharts.com/modules/data.js"></script>

<table id="datatable" style="display:none">
	<thead>
		
	</thead>
	<tbody>
		<tr>
			<th></th>
			<td></td>
			
		</tr>
        <tr>
			<th>Cold Call</th>
			<td>3</td>
			
		</tr>
		<tr>
			<th>Direct Mail</th>
			<td>2</td>
			
		</tr>
		<tr>
			<th>Referral</th>
			<td>5</td>
			
		</tr>
        <tr>
			<th>Others</th>
			<td>5</td>
			
		</tr>
        <tr>
			<th>Partner</th>
			<td>5</td>
			
		</tr>
        <tr>
			<th>None</th>
			<td>5</td>
			
		</tr>
        <tr>
			<th>Website</th>
			<td>5</td>
			
		</tr>
		
	</tbody>
</table>

<script>

$(function () {
    $('#container').highcharts({
        data: {
            table: document.getElementById('datatable')
        },
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        yAxis: {
            allowDecimals: false,
            title: {
                text: 'Units'
            }
        },
        tooltip: {
            formatter: function () {
                return this.point.y + ' ' + this.point.name.toLowerCase();
            }
        }
    });
	
	
});
</script>
<style>
.highcharts-legend-item
{
    display:none;
}
#line-chat
{
	display:none;
}
tspan {
font-size: 9px;
}

</style>