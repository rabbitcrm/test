<div class="clearfix">
  <h3>Add Deal</h3>
</div>

<div class="row"><div class="col-sm-6"><? $this->load->view('MessagesView', array(messages => $messages)) ?></div></div>

<div class="row">
  <form class="form-horizontal" method="post" data-validate="parsley" action="<?=base_url()?>deals/submit">
    <div class="col-sm-12">      
      <section class="panel">
        <div class="panel-body">
          <div class="col-sm-6">
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Deal Name<?=$this->mandatoryFieldIndicator?></label>
              <div class="col-lg-9">
                <input type="text" name="deal_name" data-required="true" class="form-control">
              </div>
            </div>
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Company<?=$this->mandatoryFieldIndicator?></label>
              <div class="col-lg-9">
                <div class="btn-group col-xs-11 no-padder">
                  <select name="deal_company_id" data-required="true" class="select2-option" <? if ($_SESSION['dealCompany']) { ?>disabled="disabled"<?php } ?>>
                    <option value=""><?=$this->chooseOption?></option>
                    <?php foreach($companies as $company) { ?>
                      <option value="<?=$company->company_id?>" <? if ($company->company_id == $_SESSION['dealCompany']) { ?>selected="selected"<?php } ?>><?=$company->company_name?></option>
                    <?php } ?>
                  </select>
                </div>
                <div class="pull-right"><a href="<?=base_url()?>deals/addcompany" class="btn btn-inverse btn-xs"> <i class="icon-plus icon-large"></i> </a></div>
                <? if ($_SESSION['dealCompany']) { ?><input type="hidden" name="deal_company_id" class="form-control" value="<?=$_SESSION['dealCompany']?>"><?php } ?>
              </div>
            </div>
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Contact<?=$this->mandatoryFieldIndicator?></label>
              <div class="col-lg-9">
                <div class="btn-group col-xs-11 no-padder">
                  <select name="deal_contact_id" data-required="true" class="select2-option" <? if ($_SESSION['dealContact']) { ?>disabled="disabled"<?php } ?>>
                    <option value=""><?=$this->chooseOption?></option>
                    <?php foreach($contacts as $contact) { ?>
                      <option value="<?=$contact->contact_id?>" <? if ($contact->contact_id == $_SESSION['dealContact']) { ?>selected="selected"<?php } ?>><?=$contact->name?></option>
                    <?php } ?>
                  </select>
                </div>
                <div class="pull-right"><a href="<?=base_url()?>deals/addcontact" class="btn btn-inverse btn-xs"> <i class="icon-plus icon-large"></i> </a></div>
                <? if ($_SESSION['dealContact']) { ?><input type="hidden" name="deal_contact_id" class="form-control" value="<?=$_SESSION['dealContact']?>"><?php } ?>
              </div>
            </div>
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Deal Value<?=$this->mandatoryFieldIndicator?></label>
              <div class="col-lg-9">
                <input type="text" name="deal_amount" data-required="true" class="form-control" data-type="number">
              </div>
            </div>
          </div>

          <div class="col-sm-6">
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Stage<?=$this->mandatoryFieldIndicator?></label>
              <div class="col-lg-9">  
                <div class="btn-group col-xs-12 no-padder">
                  <select name="stage" class="select2-option" data-required="true">
                    <option value=""><?=$this->chooseOption?></option>
                    <?php foreach($fields as $stage) { if ($stage->stage) { ?>
                      <option value="<?=$stage->stage?>"><?=$stage->stage?></option>
                    <?php } } ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Assigned to</label>
              <div class="col-lg-9">
                <div class="btn-group col-xs-12 no-padder">
                  <select name="deal_owner_id" class="select2-option">
                    <?php foreach($users as $user) { ?>
                      <option value="<?=$user->user_id?>" <?php if ($user->user_id == $this->user->user_id) { ?> selected="selected"<?php } ?>><?=$user->name?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Target Date<?=$this->mandatoryFieldIndicator?></label>
              <div class="col-lg-9">
                <input type="text" name="exp_close" data-required="true" class="form-control datepicker" value="<?=$this->today?>" data-date-format="dd-mm-yyyy" placeholder="<?=$this->chooseDate?>">
              </div>
            </div>
            <div class="form-group m-b-small">
              <label class="col-lg-3 control-label">Summary</label>
              <div class="col-lg-9">
                <textarea name="summary" rows="3" class="form-control"></textarea>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- .accordion -->
      <div class="panel-group m-b" id="accordion2">
        <div class="panel">
          <div class="panel-heading fieldset-head">
            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
              More
              <span class="caret pull-right"></span>
            </a>
          </div>
          <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
              <div class="col-sm-6">
                <div class="form-group m-b-small">
                  <label class="col-lg-3 control-label">Source</label>
                  <div class="col-lg-9">
                    <div class="btn-group col-xs-12 no-padder">
                      <select name="source" class="select2-option">
                        <option value=""><?=$this->chooseOption?></option>
                        <?php foreach($fields as $source) { if ($source->source) { ?>
                          <option value="<?=$source->source?>"><?=$source->source?></option>
                        <?php } } ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="form-group m-b-small">
                  <label class="col-lg-3 control-label">Industry</label>
                  <div class="col-lg-9">
                    <div class="btn-group col-xs-12 no-padder">
                      <select name="industry" class="select2-option">
                        <option value=""><?=$this->chooseOption?></option>
                        <?php foreach($fields as $industry) { if ($industry->industry) { ?>
                          <option value="<?=$industry->industry?>"><?=$industry->industry?></option>
                        <?php } } ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="form-group m-b-small">
                  <label class="col-lg-3 control-label">Campaign</label>
                  <div class="col-lg-9">
                    <div class="btn-group col-xs-12 no-padder">
                      <select name="deal_application" class="select2-option">
                        <option value=""><?=$this->chooseOption?></option>
                        <?php foreach($fields as $application) { if ($application->application) { ?>
                          <option value="<?=$application->application?>"><?=$application->application?></option>
                        <?php } } ?>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- / .accordion -->
    </div>

    <div class="col-sm-12">
      <div class="form-group">
        <button type="submit" class="btn btn-primary m-l">Create</button>
      </div>
    </div>
  </form>
</div>