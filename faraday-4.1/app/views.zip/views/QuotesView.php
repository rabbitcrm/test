<div class="clearfix">
  <h3>
  	Quote Worklist
  	<?php if ($this->isAdmin && $quotes[0]) { ?><a href="<?=base_url()?>quotes/export" class="btn btn-sm btn-inverse pull-right m-l-small" style="margin-top: -2px;"><i class="icon-arrow-up"></i> Export</a><?php } ?>
  </h3>
</div>

<?php if ($quotes[0]) { ?>

  <?php $this->load->view('FiltersView', array('actionPath' => 'quotes', 'fSource' => $quotes)); ?>

  <div class="bcz-filters-content">
    <?php $this->load->view('DataTableView', array('sourcePath' => 'quotes/getquotesjson')); ?>
  </div>

<?php } else {

  $this->load->view('NoDataView');

} ?>