<!-- header -->
<header id="header" class="navbar">
  <ul class="nav navbar-nav navbar-avatar pull-right">
    <li class="dropdown">
      <a href="" class="dropdown-toggle" data-toggle="dropdown">            
        <span class="hidden-xs-only"><?=$this->user->name?ucfirst($this->user->name):$this->user->username?></span>
        <span class="thumb-small avatar inline"><img src="<?=$this->user->profile_pic?$this->user->profile_pic:(base_url().'assets/img/default-profile-pic.png')?>" alt="Mika Sokeil" class="img-circle" /></span>
        <b class="caret hidden-xs-only"></b>
      </a>
      <ul class="dropdown-menu">
        <li><a href="<?=base_url()?>profile"><i class="icon-user"></i><?=$this->isAdmin?'Profile':'Profile'?></a></li>
        <?php if ($this->isAdmin) { ?><li><a href="<?=base_url()?>settings"><i class="icon-cog"></i>Settings</a></li><?php } ?>
        <li class="divider"></li>
        <li><a href="<?=base_url()?>logout"><i class="icon-signout"></i>Logout</a></li>
        <li class="divider"></li>
        <li><a href="<?=base_url()?>help"><i class="icon-info-sign"></i>Help / Support</a></li>
      </ul>
    </li>
  </ul>
  
  <a class="navbar-brand no-padder" href="<?=base_url()?>"><span class="navbar-logo-wrapper"><img src="<?=$_SESSION['bcz_org_logo']?$_SESSION['bcz_org_logo']:base_url().'assets/img/logo.jpg'?>" width="139" height="" border="0" title="Skyzon" alt="" <?php if(!$_SESSION['bcz_org_logo']) { ?>style="margin-top: 8px;"<?php } ?> /></span></a>
  <button type="button" class="btn btn-link pull-left nav-toggle visible-xs" data-toggle="class:slide-nav slide-nav-left" data-target="body">
    <i class="icon-reorder icon-xlarge text-default"></i>
  </button>

  <ul class="nav navbar-nav hidden-xs">
    <li>
      <div class="m-t-small">
        <button class="dropdown-toggle btn btn-sm btn-inverse" data-toggle="dropdown"><i class="icon-plus"></i> ADD</button>

        <ul class="dropdown-menu">
          <li><a href="<?=base_url()?>leads/add"><i class="icon-lightbulb"></i>Lead</a></li>
          <li class="divider"></li>
          <li><a href="<?=base_url()?>deals/add"><i class="icon-thumbs-up-alt"></i>Deal</a></li>
          <li class="divider"></li>
          <li><a href="<?=base_url()?>tasks/add"><i class="icon-check"></i>Task</a></li>
          <li class="divider"></li>
          <li><a href="<?=base_url()?>contacts/add"><i class="icon-book"></i>Contact</a></li>
          <li class="divider"></li>
          <li><a href="<?=base_url()?>companies/add"><i class="icon-building"></i>Company</a></li>
          <li class="divider"></li>
          <li><a href="<?=base_url()?>products/add"><i class="icon-hdd"></i>Product</a></li>
          <li class="divider"></li>
          <li><a href="<?=base_url()?>cases/add"><i class="icon-ticket"></i>Ticket</a></li>
        </ul>
      </div>
    </li>
  </ul>

  <form class="navbar-form pull-left shift bcz-search-form" action="search" data-toggle="shift:appendTo" data-target=".nav-primary">
    <i class="icon-search text-muted"></i>
    <input id="bcz_search" name="q" type="text" class="input-sm form-control dropdown-toggle" placeholder="Search" data-toggle="dropdown" value="<?=$_REQUEST['q']?>">
    <ul class="dropdown-menu hide"></ul>
  </form>
</header>
<!-- / header -->