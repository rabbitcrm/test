<div class="panel">
  <div class="panel-body">
    <p class="h4">No data found!</p>
  </div>
</div>