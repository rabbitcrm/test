<div class="clearfix">
  <h3>
  	Contact Worklist
  	<?php if ($this->isAdmin && $contacts[0]) { ?><a href="<?=base_url()?>contacts/export" class="btn btn-sm btn-inverse pull-right m-l-small" style="margin-top: -2px;"><i class="icon-arrow-up"></i> Export</a><?php } ?>
  	<a href="<?=base_url()?>contacts/add" class="btn btn-sm btn-inverse pull-right" style="margin-top: -2px;"><i class="icon-plus"></i> ADD</a>
  </h3>
</div>

<?php if ($contacts[0]) { ?>

  <?php $this->load->view('FiltersView', array('actionPath' => 'contacts', 'fSource' => $contacts)); ?>

  <div class="bcz-filters-content">
    <?php $this->load->view('DataTableView', array('sourcePath' => 'contacts/getcontactsjson')); ?>
  </div>

<?php } else {

  $this->load->view('NoDataView');

} ?>