<!-- .modal -->
<div id="upgrade_message_modal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content"><!-- .modal-content -->
        <div class="modal-body">
          Your account is limited for 3 users only, please upgrade to add more.
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Ok</button>
        </div>
      </div><!-- /.modal-content -->
    </div>
</div>
<!-- / .modal -->