<div class="clearfix">
  <h3>Task Worklist
  	<?php if ($this->isAdmin && $tasks[0]) { ?><a href="<?=base_url()?>tasks/export" class="btn btn-sm btn-inverse pull-right m-l-small" style="margin-top: -2px;"><i class="icon-arrow-up"></i> Export</a><?php } ?>
  	<a href="<?=base_url()?>tasks/add" class="btn btn-sm btn-inverse pull-right" style="margin-top: -2px;"><i class="icon-plus"></i> ADD</a>
  </h3>
</div>

<?php if ($tasks[0]) { ?>

  <?php $this->load->view('FiltersView', array('actionPath' => 'tasks', 'fSource' => $tasks)); ?>

  <div class="bcz-filters-content">
    <?php $this->load->view('DataTableView', array('sourcePath' => 'tasks/gettasksjson')); ?>
  </div>

<?php } else {

  $this->load->view('NoDataView');

} ?>