<!--
<div id="users_org_chart"></div>
<ul id="users_org_chart_source" class="hide">
  <li>
    CEO(Admin)
    <ul>
      <li>
        Manager 1
        <ul>
          <li>Executive 1</li>
          <li>Executive 2</li>
        </ul>
      </li>
      <li>
        Manager 2
        <ul>
          <li>Executive 3</li>
          <li>Executive 4</li>
          <li>Executive 5</li>
        </ul>
      </li>
      <li>
        Manager 3
      </li>
      <li>
        Manager 4
        <ul>
          <li>Executive 6</li>
        </ul>
      </li>
      <li>
        Manager 5
      </li>
    </ul>
  </li>
</ul>
-->

<!--
<div id="tree">
  <div id="root">Root Node</div>

  <ul>
    <li>
      CEO(Admin)
      <ul>
        <li>
          Manager 1
          <ul>
            <li>Executive 1</li>
            <li>Executive 2</li>
          </ul>
        </li>
        <li>
          Manager 2
          <ul>
            <li>Executive 3</li>
            <li>Executive 4</li>
            <li>Executive 5</li>
          </ul>
        </li>
        <li>
          Manager 3
        </li>
        <li>
          Manager 4
          <ul>
            <li>Executive 6</li>
          </ul>
        </li>
        <li>
          Manager 5
        </li>
      </ul>
    </li>
  </ul>
</div>
<div id="spacetree"></div>
-->

<?php $this->load->view('DataTableView', array('cols' => array_merge(array_values($this->userTableCols), array('actions')), 'sourcePath' => "settings/getusersjson")); ?>

<?php //$this->load->view('DataTableView', array('urlFlag' => false)); ?>