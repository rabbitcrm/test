dfsdfs sd fsdf<section class="panel"> 
  <div class="wizard clearfix">
    <ul class="steps">
      <?php foreach ($stages as $sid => $stage) { ?>
        <li data-stage="<?=$stage?>" <?php if ($stage == $pageStage) { ?>class="active"<?php } ?>><span class="badge <?php if ($stage == $pageStage) { ?>badge-info<?php } ?>"><?=$sid+1?></span><?=$stage?></li>
      <?php if ($stage == $pageStage) $activeStageIindex = $sid; } ?>
    </ul>
    <div class="actions" data-id="<?=$pageId?>">
      <button type="button" class="btn btn-white btn-xs prev-btn <?=($activeStageIindex == 0)?'hide':''?>"><i class="icon-chevron-left icon-large"></i></button>
      <button type="button" class="btn btn-white btn-xs next-btn <?=($activeStageIindex == (count($stages) - 1))?'hide':''?>"><i class="icon-chevron-right icon-large"></i></button>
    </div>
  </div>
</section>