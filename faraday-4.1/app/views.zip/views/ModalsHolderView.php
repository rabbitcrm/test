<div class="modals-holder">
	<?php 
		if ($this->bodyClass == 'lead-details') {
			$this->load->view("ReassignLeadModal");
			$this->load->view("ConvertLeadModal");
		}
	?>
	
	<?php if ($this->bodyClass == 'deal-details') $this->load->view("ReassignDealModal"); ?>

	<?php if ($this->bodyClass == 'task-details') $this->load->view("ReassignTaskModal"); ?>

	<?php if ($this->bodyClass == 'case-details') $this->load->view("ReassignCaseModal"); ?>

	<?php 
		if ($this->bodyClass == 'settings') {
			$this->load->view("AddUserModal");
			echo '<div id="edit_user_modal" class="modal fade"></div>';
			//$this->load->view("EditUserModal");
			$this->load->view("DeleteUserConfirmationModal");
			$this->load->view("ResetUserConfirmationModal");
			$this->load->view("AddSettingModal");
			$this->load->view("EditSettingModal");
			$this->load->view("DeleteSettingConfirmationModal");
		}
	?>

	<?php if ($this->bodyClass == 'quote-details') $this->load->view("GenerateSoModal"); ?>

	<?php 
		if ($this->bodyClass == 'docs') {
			$this->load->view("CreateFolderModal");
			$this->load->view("UploadDocModal");
		}
	?>

	<?php $this->load->view("AddFileModal"); ?>
	<?php $this->load->view("CreateTaskModal"); ?>
	<?php $this->load->view("CreateDealModal"); ?>
	<?php $this->load->view("CreateContactModal"); ?>
	<?php $this->load->view("ConfirmationModal"); ?>
	<?php $this->load->view("UpgradeMessageModal"); ?>
	<?php $this->load->view("ComposeEmailModal"); ?>
	<?php $this->load->view("CreateProductModal"); ?>
</div>