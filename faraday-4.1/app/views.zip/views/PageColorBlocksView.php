<div class="row padder bcz-colored-boxes">
  <?php foreach ($colorBlocks as $colorBlock) { ?>
  <div class="col-sm-<?=$colorBlock['cols']?$colorBlock['cols']:3?> bg-<?=$colorBlock['color']?> padder-v text-center">
    <div class="h3"><?=$colorBlock['head']?></div>
    <div class="h2 <?=$colorBlock['bodyCls']?>">
    	<?php if ($colorBlock['link']) { ?><a href="<?=base_url().$colorBlock['link']?>" class="text-white"><?php } ?>
    	<?=$colorBlock['body']?(($colorBlock['type'] == 'date')?convertDateTime($colorBlock['body']):$colorBlock['body']):$this->noDataChar?>
    	<?php if ($colorBlock['link']) { ?></a><?php } ?>
    </div>
  </div>
  <?php } ?>
</div>