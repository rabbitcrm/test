<!-- .scrollable -->
<section class="panel" id="top_deals">
  <header class="panel-heading h5">Top Deals</header>
  <section class="panel-body">
    <?php if ($deals[0]) { foreach ($topDeals as $did => $deal) { ?>
      <article class="media">
        <div class="media-body">
          <div class="pull-right media-mini text-center text-muted">
            <small class="label bg-primary"><?=$deal->deal_amount?></small>
          </div>
          <a href="<?=base_url()?>deals/details/<?=$deal->deal_id?>" class="h4"><?=$deal->deal_name?></a>
        </div>
      </article>
      <?php if ($did < (count($deals) -1)) { ?><div class="line pull-in"></div><?php } ?>
    <?php } } else { ?>
      <p class="bcz-no-data-msg h5">No deals found.</p>
    <?php } ?>
  </section>
</section>
<!-- / scrollable -->