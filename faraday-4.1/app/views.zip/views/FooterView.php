<!-- footer -->
<footer id="footer">
  <div class="text-center padder clearfix">
    <p>
      <small>&copy;2012 Skyzon, All Rights Reserved.</small><br><br>
    </p>
  </div>
</footer>
<!-- / footer -->