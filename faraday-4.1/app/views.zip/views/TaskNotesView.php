<!-- .scrollable -->
<section class="panel" id="recent_notes">
  <header class="panel-heading h5">Task</header>
  <section class="panel-body">
  
  <div id="tabs">
  <ul>
  	<li ><a href="#tabs-1">Completed Tasks</a></li>
    <li ><a href="#tabs-2">Today's Task</a></li>
    <li ><a href="#tabs-3">Up Coming Tasks</a></li>
    
  </ul>
  <div id="tabs-1">
    
    <?php if ($complet_tasks[0]) { foreach ($complet_tasks as $nid => $complet_task) { ?>
     <table >
      <article class="media">
     
     <tr>
     <td>
        <div class="pull-left thumb-small">
          <img src="<?=$task->profile_pic?($complet_task->fullPicPath ? '' : base_url().$complet_task->imagesPath).$complet_task->profile_pic:(base_url().'assets/img/default-profile-pic.png')?>" width="40" />
        </div>
        </td>
        
        <div class="media-body">
        
         <td class="task_tital">
         
          <a href="<?=base_url().$complet_task->item_type?>s/details/<?=$complet_task->task_id?>" class="h5">
		 <?php $string = strip_tags($complet_task->task_name);

if (strlen($string) >150) {
    // truncate string
    $stringCut = substr($string, 0, 150);
    // make sure it ends in a word so assassinate doesn't become ass...
    $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}

		  ?>
		  <?=$string;?></a>
         <?php /*?> <small class="block m-b-none"><?=$complet_task->task_name?></small><?php */?>
         </td>
          <?php $company_name = strip_tags($complet_task->company_name);
if (strlen($company_name) > 150) {
    // truncate string
    $stringCut = substr($company_name, 0,150);
    // make sure it ends in a word so assassinate doesn't become ass...
    $company_name = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}
		  ?>
         <td class="task_company"><small class="block m-b-none"><?=$company_name?></small></td>
         
         <td class="task_priority"><small class="block m-b-none"><?=$complet_task->priority?></small></td>
        
        <td class="task_date">
          <div class="pull-right media-mini text-center text-muted">
            <strong class="h4"><?=convertDateTime($complet_task->due_date, 'd')?></strong><br>
            <small class="label bg-light"><?=convertDateTime($complet_task->due_date, 'M')?> <?=convertDateTime($complet_task->due_date, 'y')?></small>
          </div>
         </td>
        
          
        </div>
        </tr>
      </article>
      </table>
      <?php if ($nid < (count($complet_task) -1)) { ?><div class="line pull-in"></div><?php } ?>
    <?php } ?><?php } else { ?>
      <p class="bcz-no-data-msg h5">No Completed Tasks.</p>
    <?php } ?>
  </div>
  
  
  
  
  
  
  
  
  
  
  <div id="tabs-2">
  
  
  
  
 
    <?php if ($tasks[0]) { foreach ($tasks as $nid => $task) { ?>
      <table >
      <article class="media">
     
     <tr>
     <td>
        <div class="pull-left thumb-small">
          <img src="<?=$task->profile_pic?($task->fullPicPath ? '' : base_url().$task->imagesPath).$task->profile_pic:(base_url().'assets/img/default-profile-pic.png')?>" width="40" />
        </div>
        </td>
        
        <div class="media-body">
        
         <td class="task_tital">
         
          <a href="<?=base_url().$task->item_type?>s/details/<?=$task->task_id?>" class="h5">
		 <?php $string = strip_tags($task->task_name);

if (strlen($string) >150) {
    // truncate string
    $stringCut = substr($string, 0, 150);
    // make sure it ends in a word so assassinate doesn't become ass...
    $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}

		  ?>
		  <?=$string;?></a>
         <?php /*?> <small class="block m-b-none"><?=$task->task_name?></small><?php */?>
         </td>
          <?php $company_name = strip_tags($task->company_name);
if (strlen($company_name) > 150) {
    // truncate string
    $stringCut = substr($company_name, 0,150);
    // make sure it ends in a word so assassinate doesn't become ass...
    $company_name = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}
		  ?>
         <td class="task_company"><small class="block m-b-none"><?=$company_name?></small></td>
         
         <td class="task_priority"><small class="block m-b-none"><?=$task->priority?></small></td>
        
        <td class="task_date">
          <div class="pull-right media-mini text-center text-muted">
            <strong class="h4"><?=convertDateTime($task->due_date, 'd')?></strong><br>
            <small class="label bg-light"><?=convertDateTime($task->due_date, 'M')?> <?=convertDateTime($task->due_date, 'y')?></small>
          </div>
         </td>
        
          
        </div>
        </tr>
      </article>
      </table>
      <?php if ($nid < (count($tasks) -1)) { ?><div class="line pull-in"></div><?php } ?>
    <?php } ?><?php } else { ?>
      <p class="bcz-no-data-msg h5">No Today's Task.</p>
    <?php } ?>
  

  </div>
  
  <div id="tabs-3">
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    
  
  
    <?php if ($coming_tasks[0]) { foreach ($coming_tasks as $nid => $task) { ?>
     <table >
      <article class="media">
     
     <tr>
     <td>
        <div class="pull-left thumb-small">
          <img src="<?=$task->profile_pic?($task->fullPicPath ? '' : base_url().$task->imagesPath).$task->profile_pic:(base_url().'assets/img/default-profile-pic.png')?>" width="40" />
        </div>
        </td>
        
        <div class="media-body">
        
         <td class="task_tital">
         
          <a href="<?=base_url().$task->item_type?>s/details/<?=$task->task_id?>" class="h5">
		 <?php $string = strip_tags($task->task_name);

if (strlen($string) >150) {
    // truncate string
    $stringCut = substr($string, 0, 150);
    // make sure it ends in a word so assassinate doesn't become ass...
    $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}

		  ?>
		  <?=$string;?></a>
         <?php /*?> <small class="block m-b-none"><?=$task->task_name?></small><?php */?>
         </td>
          <?php $company_name = strip_tags($task->company_name);
if (strlen($company_name) > 150) {
    // truncate string
    $stringCut = substr($company_name, 0,150);
    // make sure it ends in a word so assassinate doesn't become ass...
    $company_name = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}
		  ?>
         <td class="task_company"><small class="block m-b-none"><?=$company_name?></small></td>
         
         <td class="task_priority"><small class="block m-b-none"><?=$task->priority?></small></td>
        
        <td class="task_date">
          <div class="pull-right media-mini text-center text-muted">
            <strong class="h4"><?=convertDateTime($task->due_date, 'd')?></strong><br>
            <small class="label bg-light"><?=convertDateTime($task->due_date, 'M')?> <?=convertDateTime($task->due_date, 'y')?></small>
          </div>
         </td>
        
          
        </div>
        </tr>
      </article>
      </table>
      <?php if ($nid < (count($tasks) -1)) { ?><div class="line pull-in"></div><?php } ?>
    <?php } ?><?php } else { ?>
      <p class="bcz-no-data-msg h5">No Up Coming Tasks.</p>
    <?php } ?>
    
    

  </div>
</div>


  </section>
</section>
<!-- / scrollable -->