<div class="clearfix">
  <h3>Help / Support</h3>
</div>

<div class="row">
  <div class="col-sm-12">      
    <section class="panel">
    	<div class="panel-body">
        <div class="col-sm-6">
          <h4 class="col-sm-6">Company:</h4>
          <h4 class="col-sm-6">Skyzon</h4>
          <h4 class="col-sm-6">Contact No:</h4>
          <h4 class="col-sm-6"><?=$this->supportInfo['contact']?></h4>
          <h4 class="col-sm-6">Fax No:</h4>
          <h4 class="col-sm-6"><?=$this->supportInfo['fax']?></h4>
          <h4 class="col-sm-6">Email ID:</h4>
          <h4 class="col-sm-6"><?=$this->supportInfo['email']?></h4>
          <h4 class="col-sm-6">Website:</h4>
          <h4 class="col-sm-6"><?=$this->supportInfo['website']?></h4>
        </div>
    	</div>
    </section>
  </div>
</div>