<section class="panel">
  <div class="panel-body bcz-filters" data-filter-action="<?=base_url().$actionPath?>">
    <div class="col-sm-1 no-padder m-t-large">
      <div class="form-group h4 m-b-none m-t-mini">
        <label class="control-label">Filters:</label>
      </div>
    </div>

    <div class="col-sm-11 no-padder-r">
      <?php $colWidth = min(4, (12 / count($filters))); foreach ($filters as $fLabel => $fData) { ?>
        <div class="col-sm-<?=$colWidth?> m-t-mini m-b-mini no-padder-l <?=($mobFilters && !in_array($fData['col'], $mobFilters))?'hidden-xs':''?>">
          <label class="col-lg-12 control-label m-t-mini m-r-mini no-padder"><?=ucfirst($fLabel)?>:</label>
          <div class="col-lg-12 no-padder">
            <div class="btn-group col-xs-12 no-padder">
              <select name="<?=$fData['col']?>" class="select2-option">
                <option value="">All</option>

                <?php
                  if ($fData['type'] == 'date') {
                ?>

                <option value="curr_month">This Month</option>
                <option value="last_month">Last Month</option>
                <option value="curr_week">This Week</option>
                <option value="last_week">Last Week</option>
                <option value="90_days">Last 90 Days</option>
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>

                <?php
                  } else {
                  $fOptions = array();
                  foreach ($fSource as $fRow) {
                    if ($fRow->$fData['col'] && !in_array($fRow->$fData['col'], $fOptions)) {                  
                      $fOptions[] = $fRow->$fData['col'];
                ?>

                  <option value="<?=$fRow->$fData['col']?>"><?=$fRow->$fData['alias']?></option>

                <?php } } } ?>
                
              </select>
            </div>
          </div>
        </div>
      <?php } ?>
    </div>
  </div>
</section>