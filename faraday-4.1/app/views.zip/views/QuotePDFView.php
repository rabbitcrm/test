<!DOCTYPE html>
<html lang="en" class="no-js">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title> :: SkyzonCRM<?=($this->pageTitle ? ' | '.ucfirst($this->pageTitle) : '')?> :: </title>
    <meta name="description" content="<?=$this->pageDesc;?>">
    <meta name="author" content="Siva Durgarao">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Template Styles -->
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/pdf-styles.css">
  </head>
  
  <body>
    <h3>
      Quotation
    </h3>

    <table class="table" cellspacing="0">
      <tbody>
        <tr>
          <th width="50%">
            <br><br>
            <a href="<?=$organization->website?>"><img src="<?=$_SESSION['bcz_user']->org_logo?$_SESSION['bcz_user']->org_logo:($_SESSION['bcz_org_logo']?$_SESSION['bcz_org_logo']:(base_url().'assets/img/logo.jpg'))?>" width="200" height="50" border="0" title="Skyzon" alt="" /></a>
            <p>
              <?=$organization->name?><br>
              <?=$organization->address?><br>
              <?=$organization->city?>, <?=$organization->state?> - <?=$organization->pcode?><br>
              <?=$organization->country?><br><br>
              Phone: <?=$organization->phone?><br>
              Email: <?=$organization->email?><br>
              Fax: <?=$organization->fax?><br><br>
            </p>
          </th>
          <th width="50%" class="text-right">
            <h4>Quote No: <?=$quote->quote_no?></h4>
            <strong>Quote Date: <?=convertDateTime($quote->quote_create_date)?></strong><br>
            <strong>Valid Till: <?=convertDateTime($quote->valid_till)?></strong>
          </th>
        </tr>
        <tr class="well">
          <td width="50%">
            <br><br>
            <strong>BILLING ADDRESS:</strong><br><br>
            <strong><?=$quote->name?></strong><br>
            <?=$quote->bill_addr?><br>
            <?=$quote->bill_city?>, <?=$quote->bill_state?> - <?=$quote->bill_pcode?><br>
            <?=$quote->bill_country?><br>
            Email: <?=$quote->user_email?><br>
          </td>
          <td width="50%">
            <br><br>
            <strong>SHIPPING ADDRESS:</strong><br><br>
            <strong><?=$quote->name?></strong><br>
            <?=$quote->ship_addr?><br>
            <?=$quote->ship_city?><br>
            <?=$quote->ship_state?> - <?=$quote->ship_pcode?><br>
            <?=$quote->ship_country?><br>
            Email: <?=$quote->user_email?><br>
          </td>
        </tr>
      </tbody>
    </table>

    <table cellspacing="0" class="table text-center with-border">
      <thead>
        <tr>
          <th width="7.5%"><br><br><br><br>No</th>
          <th width="40%"><br><br><br><br>SUMMARY</th>
          <th width="12.5%"><br><br><br><br>PRICE</th>
          <th width="7.5%"><br><br><br><br>QTY</th>
          <th width="10%"><br><br><br><br>DISCOUNT</th>
          <th width="10%"><br><br><br><br>VAT %</th>
          <th width="12.5%"><br><br><br><br>AMOUNT</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($quote->items as $ik => $item) { ?>
        <tr>
          <td width="7.5%"><br><br><?=$ik?></td>
          <td width="40%"><br><br><?=$item['product']->product_name . ' - ' . $item['product']->partno . '<br><font size="-2">' . $item['desc'] . '</font>'?></td>
          <td width="12.5%"><br><br><?=$item['price']?></td>
          <td width="7.5%"><br><br><?=$item['qty']?></td>
          <td width="10%"><br><br><?=$item['discount']?></td>
          <td width="10%"><br><br><?=$item['vat']?></td>
          <td width="12.5%"><br><br><?=$item['amount']?></td>
        </tr>
        <?php } ?>
        <tr>
          <td width="66%" style="text-align: left;"><br><br>Currency : <?=$quote->quote_currency?></td>
          <td width="25%" style="text-align: right;"><br><br><strong>Frieght</strong></td>
          <td width="9%" style="text-align: left;"><br><br><?=$quote->frieght?></td>
        </tr>
        <tr>
          <th width="66%" style="text-align: left;"><br><br>VAT No : <?=$organization->TIN?></th>
          <th width="25%" style="text-align: right;"><br><br><strong>Installation</strong></th>
          <th width="9%" style="text-align: left;"><br><br><?=$quote->install?></th>
        </tr>
        <tr>
          <th width="66%" style="text-align: left;"><br><br>CST : <?=$organization->CST?></th>
          <th width="25%" style="text-align: right;"><br><br><strong>TOTAL</strong></th>
          <th width="9%" style="text-align: left;"><br><br><strong><?=$quote->total?></strong></th>
        </tr>
      </tbody>
    </table>

    <br><br><br>
    <h5>
      Bank Account Details
    </h5>
    <table class="table" cellspacing="0">
      <tbody>
        <tr>
          <th width="30%">
            Bank Name<br>
            Account Name<br>
            Account No<br>
            IFSC Code<br>
            Bank Address<br>
          </th>
          <th width="70%">
            <?=$organization->bank_name?><br>
            <?=$organization->account_name?><br>
            <?=$organization->account_no?><br>
            <?=$organization->IFSC_code?><br>
            <?=$organization->bank_addr?>
          </th>
        </tr>
      </tbody>
    </table>

    <h5>
      Terms and Conditions
    </h5>
    <table class="table" cellspacing="0">
      <tbody>
        <tr>
          <th width="30%">
            Delivery<br>
            Carrier<br>
            Payment<br><br>
          </th>
          <th width="70%">
            <?=$quote->delivery?><br>
            <?=$quote->carrier?><br>
            <?=$quote->payment?>
          </th>
        </tr>
      </tbody>
    </table>

    <br><br><br><br><br><br><br><br><br><br>
    <p style="color: #999;">This is a computer generated quote from SkyzonCRM www.skyzon.com</p>
</body>
</html>