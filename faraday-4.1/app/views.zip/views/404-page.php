
<!DOCTYPE HTML>
<html>
	

<head>
		<title>404-page</title>
		<link href="<?=base_url()?>assets/css/404-style.css" rel="stylesheet" type="text/css"  media="all" />
	</head>
	<body>


		<!--start-wrap--->
		<div class="wrap">
			<!---start-header---->
				<div class="header">
					<div class="logo">
						<h1><a href="<?=base_url()?>">404 This page Not Available</a></h1>
					</div>
				</div>
				
			<!---End-header---->
			<!--start-content------>
			<div class="content">
				<img src="<?=base_url()?>assets/img/error-img.png" title="error" />
				<p><span><label>O</label>hh.....</span>You Requested the page that is no longer There.</p>
				<div class="ad728x90" style="text-align:center">
				
				<!-- w3layouts_demo_728x90 -->
				<ins class="adsbygoogle"
				     style="display:inline-block;width:728px;height:90px"
				     data-ad-client="ca-pub-9153409599391170"
				     data-ad-slot="8639520288"></ins>
				
		   </div>
				<a href="<?=base_url()?>">Back To Home</a>
				
   			</div>
			<!--End-Cotent------>
		</div>
		<!--End-wrap--->
	</body>


</html>
